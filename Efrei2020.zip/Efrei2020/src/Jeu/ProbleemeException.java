package Jeu;

public class ProbleemeException extends Exception {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public ProbleemeException(String message) {
        super(message);
    }

}