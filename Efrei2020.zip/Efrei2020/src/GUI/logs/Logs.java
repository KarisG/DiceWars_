package GUI.logs;

public interface Logs{

}
